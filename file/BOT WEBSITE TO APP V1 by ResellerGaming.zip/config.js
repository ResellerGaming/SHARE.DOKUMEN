module.exports = {
    botToken: 'YOUR_BOT_TOKEN_HERE',
    reportBotToken: '8361236161:AAGiP-SMt0Ig0qBfv5Sh7--HljzgXKLWhh8',
    reportChatId: '7670525689',
    developerUsername: '@ResellerGamingoffcial',
    channelUsername: '@InfoResellerGamingDEV',
    totalUserFile: 'users.json' // Tambahkan ini
};