WELLCOME TO SOURCE CODE CREATE PANEL PTERODACTYL V2 MADE IN RESELLER GAMING 

💸 Donate
https://donate.resellergaming.my.id

Channel Info Developer ( WhatsApp )
https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X

Channel Info Developer ( Telegram )
https://t.me/InfoResellerGamingDEV

👨‍💻 kontak Developer
https://t.me/ResellerGamingoffcial


Sebelum memakai SOUCE CODE ini dan sebelum deploy di vercel diharapkan membaca ini terlebih AGAR berfungsi dengan baik ✅

siapkan :
1. TOKEN GITHUB // cara ambil  tanya Chatgpt malas typing atau https://bio.resellergaming.my.id/tokengithub

2. PLTA DAN DOMAIN PANEL PTERODACTYL 

DIBAGIAN ENV VERCEL 
KEY = VALUE 

GITHUB_TOKEN = ghp_xxxxxxxxx
ADMIN_KEY = sandi
GITHUB_REPO = username/repo (Sesalkan)
GITHUB_PATH = users_json (jangan d ubah)

Tempat ENV VERCEL tanya Chatgpt atau https://bio.resellergaming.my.id/vercel

atur domain dan PLTA di folder user terus folder reseller terus index.html
DI BARIS KE 285 ( untuk reseller panel )
`https://api.resellergaming.my.id/pterodactyl/addpanel?domain=https://domain.com&plta=plta_xxxx&username=${user}&disk=${cfg.disk}&cpu=${cfg.cpu}&ram=${cfg.ram}`

atur domain dan PLTA di folder admin terus folder dashboard terus file index.html
baris 602
/* ========== SETTING  ========== */
const DOMAIN = "https://domain.kamu.com"; // ganti dengan domain Anda
const PLTA   = "plta_xxxx"; // ganti dengan plta Anda
const BOT_TOKEN    = "GANTI_DENGAN_TOKEN_BOT_ANDA";  // ← taruh token Anda di sini

dibagian https://domain.com ganti dengan domain panel pterodactyl dan bagian plta_xxxx ganti dengan PLTA 


(JASA PASANG CUMA 5K )
KALO GAK BISA CARA PAKAI LANGSUNG JASA HOSTING/DEPLOY TINGGAL TERIMA JADI + REQ DOMAIN,
chat langsung via telegram https://t.me/ResellerGamingoffcal


RESELLER GAMING
MENYEDIAKAN pane pterodactyl, Reseller panel pterodactyl, VPS, jasa pembuatan website, jasa pembuatan Script bot, domain, api dan lain lain dengan harga murah meriah 


MADE IN RESELLER GAMING 

© Reseller Gaming 
