SELAMAT DATANG DI SCRIPT CREATE SUBDOMAIN VIA WEBSITE DAN BOT TELEGRAM by RESELLER GAMING NO ENC 100% DAN BISA DIPAKAI SAMA SIAPA AJA 😊🙏

💸 Donate
https://donate.resellergaming.my.id

Channel Info Developer ( WhatsApp )
https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X

Channel Info Developer ( Telegram )
https://t.me/InfoResellerGamingDEV

👨‍💻 kontak Developer
https://t.me/ResellerGamingoffcial

📑 Cara pakai 
Belum punya domain utama? bisa beli di Reseller Gaming harga start 7k (my.id/biz.id) bisa req domain dan bisa create subdomain sepuasnya. https://t.me/ResellerGamingoffcial
1. utamakan memiliki domain/domain utama dan sudah terkait dengan cloudflare (https://cloudflare.com)
2. jika sudah terkait, bikin apikey cloudflare. jika tidak tau bisa tanya Chatgpt atau nonton YouTube.
3. zone id sesuai domain masing masing.
jika tidak tau bisa tanya Chatgpt atau nonton YouTube 
4. jika sudah bisa diatur sesuaikan
  a. jika make SOUCE CODE website nya harus memakai env bawaan di VERCEL, jika tidak tau bisa hubungi ResellerGaming dan kasih uang chip untuk full pengajaran.
  b. Jika make script bot telegram aturnya di config.js 
 5. ingat subdomain type A untuk VPS/make ipv4

jangan lupa bantu donate 😊🙏 biar tambah semangat 😭
💸 Donate
https://donate.resellergaming.my.id

© Reseller Gaming Programer 