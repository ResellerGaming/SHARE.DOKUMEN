SELAMAT DATANG DI SOURCE CPANEL V1 MADE BY RESELLER GAMING. Tidak ada bayaran tapi kalo mau bantu donate boleh 😊🙏 link dibawah. 

💸 Donate
https://donate.resellergaming.my.id

Channel Info Developer ( WhatsApp )
https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X

Channel Info Developer ( Telegram )
https://t.me/InfoResellerGamingDEV

👨‍💻 kontak Developer
https://t.me/ResellerGamingoffcial

TUTORIAL MAKE SOURCE INI 😊🙏
BARIS KE 119
      <b>Link:</b> <a href="domainpanel.resellergaming.my.id" target="_blank" style="color:#0052cc;">Buka Panel</a><br>
 
ganti domain dengan domain panel dan wajib ada https:// 
contoh
https://domainpanel.com

BARIS KE 150
const res = await fetch(`https://api.resellergaming.my.id/pterodactyl/addpanel?domain=https://domainpanel.com&plta=plta_mu&username=${username}&disk=${conf.disk}&cpu=${conf.cpu}`);

GANTI BAGIAN domain ( wajib make https:// ) dan make PLTA ( cara dapat wajib ada admin panel )

© Reseller Gaming Programer 