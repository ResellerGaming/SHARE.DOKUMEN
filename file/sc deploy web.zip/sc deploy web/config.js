module.exports = {
    // Token Bot Telegram
    TELEGRAM_BOT_TOKEN: 'TOKEN_BOT_KALIAN',
    
    // Konfigurasi Vercel
    VERCEL_API_TOKEN: 'TOKEN_API_VERCEL',
    VERCEL_TEAM_ID: 'YOUR_VERCEL_TEAM_ID', // OPSIONAL
    
    // Konfigurasi Netlify
    NETLIFY_API_TOKEN: 'TOKEN_NETLIFY',
    
    // Konfigurasi GitHub
    GITHUB_USERNAME: 'NAMA_GITHUB_LU',
    GITHUB_TOKEN: 'TOKEN_GHP_LU', // GATAU CARA BUAT TOKEN GITHUB? tanya chatgpt 
    
    // Konfigurasi Channel dan Group
    CHANNEL_USERNAME: 'channelkalian', // Username channel tanpa @
    GROUP_USERNAME: 'roompublic', // Username group tanpa @
    PREMIUM_DAYS: 7, // Jumlah hari premium gratis
    
    // Daftar owner bot (isi dengan user ID Telegram)
    OWNER_IDS: [1922601716, 987654321],
    
    // Info Developer dan Channel
    DEVELOPER_USERNAME: '@ResellerGamingoffciql',
    CHANNEL_URL: 'https://t.me/channeltele',
    GROUP_URL: 'https://t.me/roompublic'
};